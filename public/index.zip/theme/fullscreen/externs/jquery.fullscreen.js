/**
 * @param {boolean=} state
 * @return {boolean|jQuery|null}
 */
jQuery.prototype.fullScreen = function(state) {};

/**
 * @return {!jQuery}
 */
jQuery.prototype.toggleFullScreen = function() {};

